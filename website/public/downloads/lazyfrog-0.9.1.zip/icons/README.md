Icon placeholders created. Replace with actual images before publishing.
