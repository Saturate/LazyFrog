/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "lazyfrog:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key, chunkId) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 		
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => (fn(event)));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		__webpack_require__.p = "";
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			129: 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = (chunkId, promises) => {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(true) { // all chunks have JS
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise((resolve, reject) => (installedChunkData = installedChunks[chunkId] = [resolve, reject]));
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = (event) => {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 		
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunklazyfrog"] = self["webpackChunklazyfrog"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

;// ./src/utils/logger.ts
/**
 * Unified logging utility for the AutoSupper extension
 * Logs to both console and optional remote server for debugging
 */
// Default number of logs to keep in storage
const DEFAULT_MAX_STORED_LOGS = 10000;
class Logger {
    constructor(context, config, parentContext) {
        this.parentContext = parentContext;
        this.config = {
            context,
            remoteLogging: config?.remoteLogging ?? true,
            remoteUrl: config?.remoteUrl ?? 'http://localhost:7856/log',
            consoleLogging: config?.consoleLogging ?? true,
            storeLogs: config?.storeLogs ?? true,
            maxStoredLogs: config?.maxStoredLogs ?? DEFAULT_MAX_STORED_LOGS,
        };
        // Load logging settings from storage
        if (typeof chrome !== 'undefined' && chrome.storage) {
            chrome.storage.local.get(['automationConfig'], (result) => {
                if (result.automationConfig?.remoteLogging !== undefined) {
                    this.config.remoteLogging = result.automationConfig.remoteLogging;
                }
                if (result.automationConfig?.storeLogs !== undefined) {
                    this.config.storeLogs = result.automationConfig.storeLogs;
                }
                if (result.automationConfig?.maxStoredLogs !== undefined) {
                    this.config.maxStoredLogs = result.automationConfig.maxStoredLogs;
                }
            });
            // Listen for changes to logging settings
            chrome.storage.onChanged.addListener((changes, areaName) => {
                if (areaName === 'local' && changes.automationConfig?.newValue) {
                    const newConfig = changes.automationConfig.newValue;
                    if (newConfig.remoteLogging !== undefined) {
                        this.config.remoteLogging = newConfig.remoteLogging;
                    }
                    if (newConfig.storeLogs !== undefined) {
                        this.config.storeLogs = newConfig.storeLogs;
                    }
                    if (newConfig.maxStoredLogs !== undefined) {
                        this.config.maxStoredLogs = newConfig.maxStoredLogs;
                    }
                }
            });
        }
    }
    /**
     * Send log to remote server
     */
    async sendToRemote(entry) {
        if (!this.config.remoteLogging)
            return;
        try {
            await fetch(this.config.remoteUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(entry),
            }).catch(() => {
                // Silently fail if remote server is not available
                // We don't want to break the extension if the debug server is down
            });
        }
        catch (error) {
            // Silently fail
        }
    }
    /**
     * Store log entry in chrome.storage
     */
    storeLog(entry) {
        if (!this.config.storeLogs)
            return;
        if (typeof chrome === 'undefined' || !chrome.storage)
            return;
        try {
            // Use callback-based API for better compatibility
            chrome.storage.local.get(['debugLogs'], (result) => {
                if (chrome.runtime.lastError) {
                    console.error('[LF] Failed to get logs:', chrome.runtime.lastError);
                    return;
                }
                const logs = result.debugLogs || [];
                // Add new log
                logs.push(entry);
                // Trim to max size (keep most recent logs)
                if (logs.length > this.config.maxStoredLogs) {
                    logs.splice(0, logs.length - this.config.maxStoredLogs);
                }
                // Save back to storage
                chrome.storage.local.set({ debugLogs: logs }, () => {
                    if (chrome.runtime.lastError) {
                        console.error('[LF] Failed to store log:', chrome.runtime.lastError);
                    }
                });
            });
        }
        catch (error) {
            // Silently fail - don't break the extension if storage fails
            console.error('[LF] Failed to store log:', error);
        }
    }
    /**
     * Format message with prefix
     */
    formatMessage(message) {
        const fullContext = this.parentContext
            ? `${this.parentContext}][${this.config.context}`
            : this.config.context;
        return `[LF][${fullContext}] ${message}`;
    }
    /**
     * Serialize data for logging
     */
    serializeData(data) {
        if (data === undefined)
            return undefined;
        try {
            // Try to stringify and parse to clean up circular references
            return JSON.parse(JSON.stringify(data));
        }
        catch (error) {
            // If that fails, return a string representation
            return String(data);
        }
    }
    /**
     * Core logging function
     */
    logInternal(level, ...args) {
        // Create formatted message for remote logging
        const message = args
            .map((arg) => {
            if (typeof arg === 'string')
                return arg;
            if (typeof arg === 'object') {
                try {
                    return JSON.stringify(arg);
                }
                catch (error) {
                    // Handle circular references gracefully
                    return '[Circular Reference]';
                }
            }
            return String(arg);
        })
            .join(' ');
        const entry = {
            timestamp: new Date().toISOString(),
            context: this.config.context,
            level,
            message,
            data: args.length > 1 ? this.serializeData(args.slice(1)) : undefined,
        };
        // Log to console using appropriate method with native object inspection
        if (this.config.consoleLogging) {
            const consoleMethod = console[level] || console.log;
            // Add LazyFrog and context prefix but preserve native console behavior
            const fullContext = this.parentContext
                ? `${this.parentContext}][${this.config.context}`
                : this.config.context;
            consoleMethod(`[LF][${fullContext}]`, ...args);
        }
        // Store in chrome.storage (non-blocking)
        this.storeLog(entry);
        // Send to remote server (non-blocking)
        this.sendToRemote(entry);
    }
    /**
     * Public logging methods - support unlimited parameters like console.log()
     */
    log(...args) {
        this.logInternal('log', ...args);
    }
    info(...args) {
        this.logInternal('info', ...args);
    }
    warn(...args) {
        this.logInternal('warn', ...args);
    }
    error(...args) {
        this.logInternal('error', ...args);
    }
    debug(...args) {
        this.logInternal('debug', ...args);
    }
    /**
     * Update logger configuration
     */
    setConfig(config) {
        this.config = { ...this.config, ...config };
    }
    /**
     * Enable/disable remote logging
     */
    setRemoteLogging(enabled) {
        this.config.remoteLogging = enabled;
    }
    /**
     * Enable/disable console logging
     */
    setConsoleLogging(enabled) {
        this.config.consoleLogging = enabled;
    }
    /**
     * Create a nested logger with additional context
     */
    createNestedLogger(nestedContext) {
        const fullContext = this.parentContext
            ? `${this.parentContext}][${this.config.context}`
            : this.config.context;
        return new Logger(nestedContext, {
            remoteLogging: this.config.remoteLogging,
            remoteUrl: this.config.remoteUrl,
            consoleLogging: this.config.consoleLogging,
        }, fullContext);
    }
}
/**
 * Factory function to create loggers for different contexts
 */
function createLogger(context, config, parentContext) {
    return new Logger(context, config, parentContext);
}
/**
 * Export stored logs as JSON
 */
async function exportLogs() {
    if (typeof chrome === 'undefined' || !chrome.storage) {
        throw new Error('Chrome storage not available');
    }
    const result = await chrome.storage.local.get(['debugLogs']);
    const logs = result.debugLogs || [];
    return JSON.stringify({
        exportDate: new Date().toISOString(),
        logCount: logs.length,
        logs,
    }, null, 2);
}
/**
 * Clear all stored logs
 */
async function clearLogs() {
    if (typeof chrome === 'undefined' || !chrome.storage) {
        throw new Error('Chrome storage not available');
    }
    await chrome.storage.local.set({ debugLogs: [] });
}
/**
 * Get log statistics
 */
async function getLogStats() {
    if (typeof chrome === 'undefined' || !chrome.storage) {
        return { count: 0 };
    }
    const result = await chrome.storage.local.get(['debugLogs']);
    const logs = result.debugLogs || [];
    return {
        count: logs.length,
        oldestLog: logs.length > 0 ? logs[0].timestamp : undefined,
        newestLog: logs.length > 0 ? logs[logs.length - 1].timestamp : undefined,
    };
}
/**
 * Pre-configured loggers for each context
 *
 * Example usage for nested contexts:
 * const gameLogger = redditLogger.createNestedLogger('GAME');
 * const combatLogger = gameLogger.createNestedLogger('COMBAT');
 *
 * This will produce logs like:
 * [LF][REDDIT][GAME] Starting mission
 * [LF][REDDIT][GAME][COMBAT] Enemy defeated
 */
const popupLogger = createLogger('POPUP');
const extensionLogger = createLogger('SW');
const redditLogger = createLogger('REDDIT');
const devvitLogger = createLogger('DEVVIT');
const devvitGIAELogger = createLogger('DEVVIT-GIAE');

;// ./src/automation/GameState.ts
/**
 * V2 Game State Tracker
 * Simple DOM-based state tracking
 */
class GameState {
    constructor() {
        // Player state
        this.livesRemaining = 3;
        // Mission progress
        this.currentEncounter = 0;
        this.totalEncounters = 0;
        // Mission info
        this.postId = null;
        this.difficulty = null;
        // Current screen type
        this.currentScreen = 'unknown';
    }
    /**
     * Update state from DOM (called every tick)
     */
    updateFromDOM() {
        this.livesRemaining = this.readLivesFromDOM();
    }
    /**
     * Read lives from .lives-container in DOM
     */
    readLivesFromDOM() {
        const livesContainer = document.querySelector('.lives-container');
        if (!livesContainer)
            return 3; // Default
        // Count filled hearts
        const filledHearts = livesContainer.querySelectorAll('img[src*="Heart_Full.png"]').length;
        return filledHearts;
    }
    /**
     * Set mission data from initialData message
     */
    setMissionData(metadata, postId) {
        this.postId = postId;
        this.totalEncounters = metadata?.mission?.encounters?.length || 0;
        this.difficulty = metadata?.mission?.difficulty || null;
        this.currentEncounter = 0;
    }
    /**
     * Update when encounter completes
     */
    onEncounterComplete(encounterIndex) {
        this.currentEncounter = encounterIndex;
    }
    /**
     * Get progress string for display
     */
    getProgress() {
        if (this.totalEncounters === 0)
            return 'Starting';
        return `${this.currentEncounter + 1}/${this.totalEncounters}`;
    }
    /**
     * Should we play safe? (low on lives)
     */
    shouldPlaySafe() {
        return this.livesRemaining <= 1;
    }
    /**
     * Is player still alive?
     */
    isAlive() {
        return this.livesRemaining > 0;
    }
}

;// ./src/automation/DecisionMaker.ts
/**
 * V2 Decision Maker
 * Smart decisions based on player state
 */
class DecisionMaker {
    constructor(gameState, config) {
        this.gameState = gameState;
        this.config = config;
    }
    /**
     * Crossroads: Fight or Skip mini boss
     */
    decideCrossroads() {
        // TODO: Re-enable play-safe logic when health tracking is ready
        // If low on lives, always skip
        // if (this.gameState.shouldPlaySafe()) {
        // 	return 'skip';
        // }
        // Use user config (default: fight)
        return this.config.crossroadsStrategy || 'fight';
    }
    /**
     * Skill Bargain: Accept or Decline
     */
    decideSkillBargain(bargainText) {
        const isPositive = this.isPositiveBargain(bargainText);
        // TODO: Re-enable play-safe logic when health tracking is ready
        // If low on lives, only accept positive bargains
        // if (this.gameState.shouldPlaySafe()) {
        // 	return isPositive ? 'accept' : 'decline';
        // }
        // Use user strategy
        const strategy = this.config.skillBargainStrategy || 'positive-only';
        if (strategy === 'always')
            return 'accept';
        if (strategy === 'never')
            return 'decline';
        // Default: positive-only
        return isPositive ? 'accept' : 'decline';
    }
    /**
     * Pick best ability from choices
     */
    pickAbility(abilities) {
        // Pick first from tier list
        for (const preferred of this.config.abilityTierList || []) {
            if (abilities.includes(preferred)) {
                return preferred;
            }
        }
        // Fallback to first available
        return abilities[0];
    }
    /**
     * Simple heuristic: more + than - means positive
     */
    isPositiveBargain(text) {
        const plusCount = (text.match(/\+/g) || []).length;
        const minusCount = (text.match(/-/g) || []).length;
        return plusCount > minusCount;
    }
}

;// ./src/automation/gameInstanceAutomation.ts
/**
 * Game Instance Automation Engine
 * Smart automation for game missions
 */



const DEFAULT_GIAE_CONFIG = {
    enabled: false,
    abilityTierList: ['IceKnifeOnTurnStart', 'LightningOnCrit', 'HealOnFirstTurn'],
    blessingStatPriority: ['Speed', 'Attack', 'Crit', 'Health', 'Defense', 'Dodge'], // Speed first for faster gameplay
    autoAcceptSkillBargains: true,
    skillBargainStrategy: 'positive-only',
    crossroadsStrategy: 'fight', // Fight mini bosses by default
    clickDelay: 1000,
};
class GameInstanceAutomationEngine {
    constructor(config) {
        this.intervalId = null;
        this.isProcessing = false;
        // Public properties for compatibility
        this.currentPostId = null;
        this.missionMetadata = null;
        // Deep merge config, ensuring arrays are properly preserved
        this.config = {
            ...DEFAULT_GIAE_CONFIG,
            ...config,
            // Ensure arrays are properly set, falling back to defaults if not provided
            abilityTierList: Array.isArray(config.abilityTierList)
                ? config.abilityTierList
                : DEFAULT_GIAE_CONFIG.abilityTierList,
            blessingStatPriority: Array.isArray(config.blessingStatPriority)
                ? config.blessingStatPriority
                : DEFAULT_GIAE_CONFIG.blessingStatPriority,
        };
        this.gameState = new GameState();
        this.decisionMaker = new DecisionMaker(this.gameState, this.config);
        this.setupMessageListener();
        devvitGIAELogger.log('Game automation engine initialized');
    }
    setupMessageListener() {
        window.addEventListener('message', (event) => {
            try {
                // initialData
                if (event.data?.type === 'devvit-message' &&
                    event.data?.data?.message?.type === 'initialData') {
                    const data = event.data.data.message.data;
                    this.gameState.setMissionData(data.missionMetadata, data.postId);
                    // Set properties for compatibility
                    this.currentPostId = data.postId;
                    this.missionMetadata = data.missionMetadata;
                    devvitGIAELogger.log('Mission started', {
                        postId: data.postId,
                        encounters: this.gameState.totalEncounters,
                        difficulty: this.gameState.difficulty,
                    });
                    // Report initial state to background
                    this.reportGameState();
                }
                // encounterResult
                if (event.data?.data?.message?.type === 'encounterResult') {
                    const result = event.data.data.message.data;
                    const idx = result.encounterAction?.encounterIndex;
                    devvitGIAELogger.log('encounterResult received', {
                        encounterIndex: idx,
                        currentEncounter: this.gameState.currentEncounter,
                        totalEncounters: this.gameState.totalEncounters,
                    });
                    if (idx !== undefined) {
                        this.gameState.onEncounterComplete(idx);
                        devvitGIAELogger.log('Encounter complete', {
                            encounterIndex: idx,
                            progress: this.gameState.getProgress(),
                            lives: this.gameState.livesRemaining,
                        });
                        // Report state update to background
                        this.reportGameState();
                    }
                }
                // missionComplete
                if (event.data?.data?.message?.type === 'missionComplete') {
                    const postId = event.data.data.message.data?.postId;
                    if (postId) {
                        devvitGIAELogger.log('Mission complete', { postId });
                        chrome.runtime.sendMessage({
                            type: 'MISSION_COMPLETED',
                            postId,
                        });
                    }
                }
            }
            catch (error) {
                devvitGIAELogger.error('Message error', { error: String(error) });
            }
        });
    }
    start() {
        if (this.intervalId)
            return;
        this.config.enabled = true;
        devvitGIAELogger.log('Starting automation');
        this.intervalId = window.setInterval(() => {
            if (this.config.enabled && !this.isProcessing) {
                this.processGame();
            }
        }, 1500);
    }
    stop() {
        devvitGIAELogger.log('Stopping automation');
        this.config.enabled = false;
        if (this.intervalId) {
            clearInterval(this.intervalId);
            this.intervalId = null;
        }
    }
    async processGame() {
        this.isProcessing = true;
        try {
            // Update state from DOM
            this.gameState.updateFromDOM();
            // Check if dead
            if (!this.gameState.isAlive()) {
                devvitGIAELogger.error('Out of lives');
                this.stop();
                chrome.runtime.sendMessage({
                    type: 'ERROR_OCCURRED',
                    message: 'Out of lives',
                });
                return;
            }
            // Find buttons
            const buttons = this.findAllButtons();
            if (buttons.length === 0)
                return;
            // Detect screen
            const screen = this.detectScreen(buttons);
            const screenChanged = this.gameState.currentScreen !== screen;
            this.gameState.currentScreen = screen;
            // Report state update if screen changed
            if (screenChanged) {
                this.reportGameState();
            }
            // Handle screen (if actionable)
            if (screen !== 'unknown' && screen !== 'in_progress') {
                devvitGIAELogger.log('Screen', {
                    screen,
                    lives: this.gameState.livesRemaining,
                    playSafe: this.gameState.shouldPlaySafe(),
                });
                await this.handleScreen(screen, buttons);
                await this.delay(this.config.clickDelay || 300);
            }
        }
        catch (error) {
            devvitGIAELogger.error('Process error', { error: String(error) });
        }
        finally {
            this.isProcessing = false;
        }
    }
    detectScreen(buttons) {
        const texts = buttons.map((b) => b.textContent?.trim().toLowerCase() || '');
        const classes = buttons.map((b) => b.className);
        // Inn check
        const tooltip = document.querySelector('.navbar-tooltip');
        if (tooltip?.textContent?.includes('Find and play missions')) {
            return 'inn';
        }
        // Screen detection
        if (classes.some((c) => c.includes('skip-button')))
            return 'skip';
        if (document.querySelector('.mission-end-footer'))
            return 'finish';
        if (texts.includes('fight') && texts.includes('skip'))
            return 'crossroads';
        if (texts.includes('accept') && texts.includes('decline'))
            return 'bargain';
        if (classes.filter((c) => c.includes('skill-button')).length > 1)
            return 'choice';
        if (classes.some((c) => c.includes('advance-button')))
            return 'battle';
        if (texts.includes('continue'))
            return 'continue';
        // In progress (only UI buttons)
        if (classes.some((c) => c.includes('volume-icon-button'))) {
            return 'in_progress';
        }
        return 'unknown';
    }
    async handleScreen(screen, buttons) {
        switch (screen) {
            case 'skip':
                this.clickByClass(buttons, 'skip-button');
                break;
            case 'battle':
                this.clickByClass(buttons, 'advance-button');
                break;
            case 'crossroads': {
                const choice = this.decisionMaker.decideCrossroads();
                devvitGIAELogger.log('Crossroads decision', { choice });
                const btn = buttons.find((b) => b.textContent?.toLowerCase().includes(choice));
                if (btn)
                    btn.click();
                break;
            }
            case 'bargain': {
                // Read bargain text from page
                const bargainText = document.body.textContent || '';
                const choice = this.decisionMaker.decideSkillBargain(bargainText);
                devvitGIAELogger.log('Bargain decision', { choice });
                const btn = buttons.find((b) => b.textContent?.toLowerCase() === choice);
                if (btn)
                    btn.click();
                break;
            }
            case 'choice': {
                const abilities = buttons
                    .filter((b) => b.classList.contains('skill-button'))
                    .map((b) => b.textContent?.trim() || '');
                const chosen = this.decisionMaker.pickAbility(abilities);
                devvitGIAELogger.log('Ability choice', { chosen, available: abilities });
                const btn = buttons.find((b) => b.textContent?.includes(chosen));
                if (btn)
                    btn.click();
                break;
            }
            case 'continue':
            case 'finish': {
                const btn = buttons.find((b) => b.textContent?.toLowerCase() === 'continue' ||
                    b.classList.contains('end-mission-button'));
                if (btn)
                    btn.click();
                break;
            }
            case 'inn':
                if (this.gameState.postId) {
                    devvitGIAELogger.log('Inn detected, completing mission', {
                        postId: this.gameState.postId,
                    });
                    chrome.runtime.sendMessage({
                        type: 'MISSION_COMPLETED',
                        postId: this.gameState.postId,
                    });
                }
                break;
        }
    }
    clickByClass(buttons, className) {
        const btn = buttons.find((b) => b.classList.contains(className));
        if (btn)
            btn.click();
    }
    findAllButtons() {
        const selectors = ['.advance-button', '.skill-button', '.skip-button', 'button'];
        const buttons = [];
        for (const selector of selectors) {
            document.querySelectorAll(selector).forEach((el) => {
                const rect = el.getBoundingClientRect();
                if (rect.width > 0 && rect.height > 0) {
                    buttons.push(el);
                }
            });
        }
        return buttons;
    }
    delay(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }
    // Public API
    updateConfig(config) {
        this.config = { ...this.config, ...config };
    }
    getState() {
        return this.config.enabled ? 'running' : 'stopped';
    }
    getGameState() {
        return {
            enabled: this.config.enabled,
            screen: this.gameState.currentScreen,
            lives: this.gameState.livesRemaining,
            progress: this.gameState.getProgress(),
            postId: this.gameState.postId,
            encounterCurrent: this.gameState.currentEncounter,
            encounterTotal: this.gameState.totalEncounters,
            playSafe: this.gameState.shouldPlaySafe(),
            difficulty: this.gameState.difficulty,
        };
    }
    // Report game state to background service worker
    reportGameState() {
        try {
            chrome.runtime.sendMessage({
                type: 'GAME_STATE_UPDATE',
                gameState: this.getGameState(),
            });
        }
        catch (error) {
            // Silently fail if background is not available
            devvitGIAELogger.error('Failed to report game state', { error: String(error) });
        }
    }
    // Save mission to database
    async saveMissionToDatabase(postId, username, metadata) {
        try {
            const mission = metadata.mission;
            if (!mission)
                return;
            // Import storage functions
            const { getMission, saveMission } = await __webpack_require__.e(/* import() */ 630).then(__webpack_require__.bind(__webpack_require__, 630));
            const existingMission = await getMission(postId);
            // Build permalink URL from postId
            const permalink = postId.startsWith('t3_')
                ? `https://www.reddit.com/r/SwordAndSupperGame/comments/${postId.slice(3)}/`
                : '';
            // Build flat MissionRecord
            const record = {
                postId,
                timestamp: existingMission?.timestamp || Date.now(),
                permalink,
                missionTitle: metadata.missionTitle || mission.foodName || 'Unknown',
                missionAuthorName: metadata.missionAuthorName || 'Unknown',
                environment: mission.environment,
                encounters: mission.encounters || [],
                minLevel: mission.minLevel,
                maxLevel: mission.maxLevel,
                difficulty: mission.difficulty,
                foodImage: mission.foodImage || '',
                foodName: mission.foodName || '',
                authorWeaponId: mission.authorWeaponId || '',
                chef: mission.chef || '',
                cart: mission.cart || '',
                rarity: mission.rarity || 'common',
                type: mission.type,
            };
            await saveMission(record);
            if (existingMission) {
                devvitGIAELogger.log('Mission data enriched', {
                    postId,
                    difficulty: record.difficulty,
                    environment: record.environment,
                });
            }
            else {
                devvitGIAELogger.log('🆕 NEW MISSION discovered', {
                    postId,
                    difficulty: record.difficulty,
                    foodName: mission.foodName,
                });
            }
        }
        catch (error) {
            devvitGIAELogger.error('Failed to save mission', { error: String(error) });
        }
    }
}

;// ./src/content/devvit/utils/dom.ts
/**
 * Game DOM utility functions
 * Functions for analyzing, extracting state, and interacting with the game DOM
 */
/**
 * Analyze the game page structure (debug function)
 */
function analyzeGamePage() {
    console.log('[DEVVIT] 📊 Analyzing game page...');
    console.log('[DEVVIT] Document title:', document.title);
    console.log('[DEVVIT] Body HTML (first 1000 chars):', document.body.innerHTML.substring(0, 1000));
    // Look for common game elements
    const buttons = document.querySelectorAll('button');
    console.log('[DEVVIT] Buttons found:', buttons.length);
    buttons.forEach((btn, i) => {
        if (i < 10) {
            console.log(`[DEVVIT] Button ${i}:`, btn.textContent, btn.className);
        }
    });
    // Look for canvas (games often use canvas)
    const canvases = document.querySelectorAll('canvas');
    console.log('[DEVVIT] Canvas elements:', canvases.length);
    // Look for divs that might contain game state
    const allDivs = document.querySelectorAll('div');
    console.log('[DEVVIT] Total divs:', allDivs.length);
    // Look for text that might indicate level/difficulty
    const bodyText = document.body.textContent || '';
    console.log('[DEVVIT] Body contains "level":', bodyText.toLowerCase().includes('level'));
    console.log('[DEVVIT] Body contains "star":', bodyText.toLowerCase().includes('star'));
    console.log('[DEVVIT] Body contains "mission":', bodyText.toLowerCase().includes('mission'));
    // Log all elements with IDs
    const elementsWithIds = document.querySelectorAll('[id]');
    console.log('[DEVVIT] Elements with IDs:', elementsWithIds.length);
    elementsWithIds.forEach((el, i) => {
        if (i < 20) {
            console.log(`[DEVVIT] ID ${i}:`, el.id, el.tagName, el.textContent?.substring(0, 50));
        }
    });
    // Log all elements with classes
    const elementsWithClasses = document.querySelectorAll('[class]');
    console.log('[DEVVIT] Elements with classes (first 20):', elementsWithClasses.length);
    Array.from(elementsWithClasses).slice(0, 20).forEach((el, i) => {
        console.log(`[DEVVIT] Class ${i}:`, el.className, el.tagName, el.textContent?.substring(0, 50));
    });
}
/**
 * Extract game state from the page
 */
function extractGameState() {
    console.log('[DEVVIT] 🔍 Extracting game state...');
    const state = {
        url: window.location.href,
        title: document.title,
        levelInfo: null,
        stars: null,
        buttons: [],
    };
    // Look for level information in the page
    const bodyText = document.body.textContent || '';
    // Try to find level number
    const levelMatch = bodyText.match(/level\s*(\d+)/i);
    if (levelMatch) {
        state.levelInfo = levelMatch[0];
    }
    // Try to find star rating
    const starMatch = bodyText.match(/(\d+)\s*stars?/i);
    if (starMatch) {
        state.stars = parseInt(starMatch[1]);
    }
    // Get all clickable buttons
    const buttons = document.querySelectorAll('button');
    buttons.forEach((btn) => {
        const text = btn.textContent?.trim();
        if (text && text.length < 100) {
            state.buttons.push(text);
        }
    });
    console.log('[DEVVIT] Extracted game state:', state);
    return state;
}
/**
 * Click a button by text content
 */
function clickButton(buttonText) {
    const buttons = Array.from(document.querySelectorAll('button'));
    const targetButton = buttons.find((btn) => btn.textContent?.trim().toLowerCase().includes(buttonText.toLowerCase()));
    if (targetButton) {
        console.log('[DEVVIT] 🖱️ Clicking button:', buttonText);
        targetButton.click();
        return true;
    }
    else {
        console.log('[DEVVIT] ❌ Button not found:', buttonText);
        return false;
    }
}
/**
 * Get all clickable elements
 */
function getClickableElements() {
    const clickable = [];
    // Buttons
    clickable.push(...Array.from(document.querySelectorAll('button')));
    // Links
    clickable.push(...Array.from(document.querySelectorAll('a')));
    // Elements with click handlers
    clickable.push(...Array.from(document.querySelectorAll('[onclick]')));
    return clickable;
}

;// ./src/content/devvit/devvit.tsx
/**
 * Game script - Runs inside the game iframe (*.devvit.net)
 * This is where we interact with the actual Sword & Supper game
 */



devvitLogger.log('Devvit content script loaded', {
    version: "0.15.1",
    buildTime: "2025-11-01T21:58:57.093Z",
    url: window.location.href,
    loadTime: new Date().toISOString(),
});
let gameAutomation = null;
// Set up message listener IMMEDIATELY to catch initialData
// This must be before the game sends the message!
window.addEventListener('message', (event) => {
    try {
        // Check for devvit-message with initialData
        if (event.data?.type === 'devvit-message') {
            const messageType = event.data?.data?.message?.type;
            devvitLogger.log('📨 devvit-message received (early listener)', {
                messageType,
                origin: event.origin,
                hasMessageData: !!event.data?.data?.message?.data,
                timestamp: new Date().toISOString(),
            });
            // If it's initialData, store it for later processing
            if (messageType === 'initialData') {
                const postId = event.data?.data?.message?.data?.postId;
                devvitLogger.log(`✅ initialData for ${postId} captured!`, event.data?.data);
                // Store the data globally so we can access it after automation engine initializes
                window.__capturedInitialData = event.data.data.message.data;
            }
        }
    }
    catch (error) {
        devvitLogger.error('Error in early message listener', { error: String(error) });
    }
});
devvitLogger.log('Early message listener installed');
// ============================================================================
// Extension Context Error Handling
// ============================================================================
/**
 * Safely send message to background script with proper error handling
 */
function safeSendMessage(message, callback) {
    try {
        chrome.runtime.sendMessage(message, (response) => {
            if (chrome.runtime.lastError) {
                const errorMsg = String(chrome.runtime.lastError.message || chrome.runtime.lastError);
                if (errorMsg.includes('Extension context invalidated')) {
                    devvitLogger.log('[ExtensionContext] Extension was updated/reloaded', {
                        error: errorMsg,
                    });
                    // Game iframe - no UI to show notification, just log
                }
                else {
                    devvitLogger.error('[ExtensionContext] Runtime error', { error: errorMsg });
                }
                return;
            }
            if (callback) {
                callback(response);
            }
        });
    }
    catch (error) {
        const errorMsg = String(error);
        if (errorMsg.includes('Extension context invalidated')) {
            devvitLogger.log('[ExtensionContext] Extension was updated/reloaded', { error: errorMsg });
        }
        else {
            devvitLogger.error('[ExtensionContext] Runtime error', { error: errorMsg });
        }
    }
}
// Control panel removed - now using BotControlPanel in reddit context
/**
 * Initialize automation engine
 */
function initializeAutomation() {
    if (gameAutomation) {
        devvitLogger.warn('Automation already initialized');
        return;
    }
    devvitLogger.log('Initializing game instance automation engine');
    // Load config from storage
    chrome.storage.local.get(['automationConfig'], async (result) => {
        const config = result.automationConfig || {};
        // Initialize game instance automation engine
        const giaeConfig = {
            enabled: false, // Will be enabled when user clicks button
            abilityTierList: config.abilityTierList || DEFAULT_GIAE_CONFIG.abilityTierList,
            blessingStatPriority: config.blessingStatPriority || DEFAULT_GIAE_CONFIG.blessingStatPriority,
            autoAcceptSkillBargains: config.autoAcceptSkillBargains !== undefined
                ? config.autoAcceptSkillBargains
                : DEFAULT_GIAE_CONFIG.autoAcceptSkillBargains,
            skillBargainStrategy: config.skillBargainStrategy || DEFAULT_GIAE_CONFIG.skillBargainStrategy,
            crossroadsStrategy: config.crossroadsStrategy || DEFAULT_GIAE_CONFIG.crossroadsStrategy,
            clickDelay: 300,
        };
        // Create automation engine
        gameAutomation = new GameInstanceAutomationEngine(giaeConfig);
        devvitLogger.log('Game instance automation engine initialized');
        devvitLogger.log('Config', { config: giaeConfig });
        // Check if we already captured initialData before the automation engine was ready
        const capturedData = window.__capturedInitialData;
        if (capturedData) {
            devvitLogger.log('Processing previously captured initialData', {
                postId: capturedData.postId,
                username: capturedData.username,
            });
            // Manually trigger the save since the automation engine wasn't listening yet
            const missionMetadata = capturedData.missionMetadata;
            const postId = capturedData.postId;
            const username = capturedData.username;
            if (missionMetadata && postId && gameAutomation) {
                // Save the captured mission data to database
                await gameAutomation.saveMissionToDatabase(postId, username, missionMetadata);
                // IMPORTANT: Also set currentPostId so it's available when mission completes
                // This is normally set by the message listener, but since we captured it early, we need to set it manually
                gameAutomation.currentPostId = postId;
                gameAutomation.missionMetadata = missionMetadata;
                devvitLogger.log('Set currentPostId from captured initialData', { postId });
            }
            // Clear the captured data
            delete window.__capturedInitialData;
        }
        // Notify background script that automation is ready (initial notification only)
        safeSendMessage({
            type: 'AUTOMATION_READY',
            config: giaeConfig,
        });
        // Process any pending START_MISSION_AUTOMATION message
        if (pendingStartMessage) {
            devvitLogger.log('Processing queued START_MISSION_AUTOMATION message');
            // Read config from storage and update before starting
            chrome.storage.local.get(['automationConfig'], (result) => {
                if (result.automationConfig) {
                    updateAutomationConfig(result.automationConfig);
                }
                toggleAutomation(true);
            });
            pendingStartMessage = null;
        }
    });
}
/**
 * Toggle automation on/off
 */
function toggleAutomation(enabled) {
    devvitLogger.log('toggleAutomation called', { enabled });
    if (!gameAutomation) {
        devvitLogger.error('Automation not initialized');
        return;
    }
    if (enabled) {
        gameAutomation.start();
        devvitLogger.log('Automation started');
    }
    else {
        gameAutomation.stop();
        devvitLogger.log('Automation stopped');
    }
    devvitLogger.log('Automation state', { state: gameAutomation.getState() });
}
/**
 * Update automation configuration
 */
function updateAutomationConfig(config) {
    if (!gameAutomation) {
        devvitLogger.error('Automation not initialized');
        return;
    }
    const giaeConfig = {
        abilityTierList: config.abilityTierList,
        blessingStatPriority: config.blessingStatPriority,
        autoAcceptSkillBargains: config.autoAcceptSkillBargains,
        skillBargainStrategy: config.skillBargainStrategy,
        crossroadsStrategy: config.crossroadsStrategy,
    };
    gameAutomation.updateConfig(giaeConfig);
    // Save to storage
    chrome.storage.local.set({ automationConfig: config });
}
// Queue for messages received before automation is ready
let pendingStartMessage = null;
// Listen for messages from Chrome extension (via background script)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    devvitLogger.log(`Received ${message.type} message`, {
        message,
    });
    switch (message.type) {
        case 'CHECK_AUTOMATION_STATUS':
            // Respond to query about automation engine state
            const isReady = gameAutomation !== null;
            const automationState = gameAutomation ? gameAutomation.getState() : null;
            sendResponse({
                isReady,
                isRunning: automationState === 'running',
                state: automationState,
            });
            break;
        case 'START_MISSION_AUTOMATION':
            if (!gameAutomation) {
                // Automation not ready yet, queue the message
                devvitLogger.log('Automation not ready, queuing START_MISSION_AUTOMATION');
                pendingStartMessage = message;
                sendResponse({ success: true, queued: true });
            }
            else {
                // Read config from storage and update before starting
                chrome.storage.local.get(['automationConfig'], (result) => {
                    if (result.automationConfig) {
                        updateAutomationConfig(result.automationConfig);
                    }
                    toggleAutomation(true);
                    sendResponse({ success: true });
                });
                return true; // Will respond asynchronously
            }
            break;
        case 'STOP_MISSION_AUTOMATION':
            toggleAutomation(false);
            sendResponse({ success: true });
            break;
        case 'STATE_CHANGED':
            // Ignore state changes - only reddit-content needs these
            sendResponse({ success: true });
            break;
        case 'GET_GAME_STATE':
            // Return current game state for status display
            if (gameAutomation) {
                const state = gameAutomation.getGameState();
                sendResponse({ gameState: state });
            }
            else {
                sendResponse({ gameState: null });
            }
            break;
        default:
            devvitLogger.warn(`Unknown message type: ${message.type}`, { message });
            sendResponse({ error: 'Unknown message type: ' + message.type });
    }
    return true; // Keep channel open for async response
});
// Initial analysis after a delay
setTimeout(() => {
    devvitLogger.log('Running initial game analysis');
    analyzeGamePage();
    extractGameState();
    // Initialize mission automation
    initializeAutomation();
}, 2000);

/******/ })()
;
//# sourceMappingURL=devvit-content.js.map