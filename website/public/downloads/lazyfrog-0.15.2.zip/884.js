"use strict";
(self["webpackChunklazyfrog"] = self["webpackChunklazyfrog"] || []).push([[884],{

/***/ 8884:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   exportAllData: () => (/* binding */ exportAllData)
/* harmony export */ });
/* harmony import */ var _buildInfo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8549);

/**
 * Export all extension data (missions, settings, etc.) to a JSON file
 */
async function exportAllData() {
    try {
        const storage = await chrome.storage.local.get(null);
        const data = {
            storage,
            exportedAt: new Date().toISOString(),
            version: _buildInfo__WEBPACK_IMPORTED_MODULE_0__/* .VERSION */ .xv,
        };
        const blob = new Blob([JSON.stringify(data, null, 2)], {
            type: 'application/json',
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `lazyfrog-export-${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }
    catch (error) {
        throw new Error('Failed to export data: ' + error);
    }
}


/***/ })

}]);
//# sourceMappingURL=884.js.map